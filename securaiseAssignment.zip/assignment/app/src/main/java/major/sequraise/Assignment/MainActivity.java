package major.sequraise.Assignment;


import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import major.sequraise.Assignment.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {

    ActivityMainBinding activityMainBinding;

    private Handler handler;


    static String TAG = "checkNetwork";
    private Runnable updateTimeRunnable;

    BroadcastReceiver batteryStatusReceiver;

    FirebaseFirestore database = FirebaseFirestore.getInstance();

    String deviceId = "";

    long sessionId = 0L;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(activityMainBinding.getRoot());
        Log.e(TAG, "The default network is now: " + "1");

        sessionId = System.currentTimeMillis();
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        callAllFunction();
        sendNotification(MainActivity.this);
        storeDataInFireStoreDataBase(Integer.parseInt(activityMainBinding.frequencyText.getText().toString()));


        activityMainBinding.frequencyText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (!editable.toString().isEmpty()) {
                    int freq = Integer.parseInt(editable.toString());
                    storeDataInFireStoreDataBase(freq);
                }
            }
        });

        activityMainBinding.manualRefreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
                MainActivity.this.finish();
            }
        });


    }

    private void updateTheCaptureCount() {

        Log.d("getDataFromtheFireStore", "1");

        List<String> key = new ArrayList<>();
        database.collection("CompleteData")
                .document("DeviceId" + deviceId)
                .collection("session" + sessionId).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {

                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot querySnapshot : task.getResult()) {
                                key.add(querySnapshot.getData().toString());
                                Log.d("getDataFromtheFireStore", "" + key.size());
                                activityMainBinding.captureCountNumber.setText("" + key.size());
                            }
                        }

                    }
                });
    }


    public void callAllFunction() {
        handler = new Handler();
        updateTimeRunnable = new Runnable() {
            @Override
            public void run() {
                getBatteryPercentage();
                getCurrentTime();
                getBatteryStatus();
                getConnectivityInfo();
                getCurrentLocation();
                handler.postDelayed(this, 1000);
            }
        };

        handler.post(updateTimeRunnable);

    }

    private void storeDataInFireStoreDataBase(int freq) {

        handler = new Handler();
        updateTimeRunnable = new Runnable() {
            @Override
            public void run() {

                String time = activityMainBinding.currentTime.getText().toString();
                String captureCount = activityMainBinding.captureCountNumber.getText().toString();
                String frequency = activityMainBinding.frequencyText.getText().toString();
                String connectivity = activityMainBinding.connectivityStatus.getText().toString();
                String batteryStatus = activityMainBinding.connectivityStatus.getText().toString();
                String batteryLevel = activityMainBinding.batteryChargingLevel.getText().toString();
                String location = activityMainBinding.locationDetail.getText().toString();

                Log.d("storeDataInFireStoreDataBase", "device Id: " + deviceId);
                DataModel dataModel = new DataModel(time, captureCount, frequency, connectivity, batteryStatus, batteryLevel, location);

                database.collection("CompleteData")
                        .document("DeviceId" + deviceId)
                        .collection("session" + sessionId)
                        .document("D" + System.currentTimeMillis())
                        .set(dataModel).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Log.d("storeDataInFireStoreDataBase", "onComplete: dataStored");
                                    updateTheCaptureCount();
                                } else {
                                    Log.d("storeDataInFireStoreDataBase", "onComplete: notStored");
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("storeDataInFireStoreDataBase", "onFailure: " + e.getLocalizedMessage());
                            }
                        });

                handler.postDelayed(this, freq * 60000);
            }

        };
        handler.post(updateTimeRunnable);
    }


    private void getBatteryStatus() {
        // Are we charging / charged?

        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = MainActivity.this.registerReceiver(null, ifilter);
        int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL;

        if (isCharging) {
            activityMainBinding.batteryChargingStatus.setText("ON");
        } else {
            activityMainBinding.batteryChargingStatus.setText("OFF");
        }

    }

    private void getBatteryPercentage() {

        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);

        int batteryLevel = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int batteryScale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        float batteryPercentage = (batteryLevel / (float) batteryScale) * 100;
        DecimalFormat format = new DecimalFormat("##.##");
        activityMainBinding.batteryChargingLevel.setText(format.format(batteryPercentage) + "%");


    }


    private void getConnectivityInfo() {

        ConnectivityManager connectivityManager = (ConnectivityManager) MainActivity.this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            activityMainBinding.connectivityStatus.setText("ON");
        } else {
            activityMainBinding.connectivityStatus.setText("OFF");
        }


    }


    private void getCurrentTime() {

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        String date = simpleDateFormat.format(calendar.getTime());
        activityMainBinding.currentTime.setText(date);

    }


    void getCurrentLocation() {
        int permission = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 101);
        }

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
        fusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();

                activityMainBinding.locationDetail.setText("long " + longitude + "°\n" + "lat " + latitude + "°");

            }
        }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("getCurrentLocation", "msg " + e.getLocalizedMessage());
            }
        });
    }


    private void sendNotification(Context context) {

        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);

        int batteryLevel = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int batteryScale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        float batteryPercentage = (batteryLevel / (float) batteryScale) * 100;
        if (batteryPercentage <= 20){

            Toast.makeText(context, "battery is low", Toast.LENGTH_SHORT).show();
            Intent notificationIntent = new Intent(context, MainActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(context, 3, notificationIntent, PendingIntent.FLAG_MUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                    .setSmallIcon(R.drawable.ic_battery_alert)
                    .setContentTitle("Battery Alert")
                    .setContentText("Your battery is below 20%.")
                    .setContentIntent(contentIntent)
                    .setAutoCancel(true);

            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(3, builder.build());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateTimeRunnable);
    }

}
