package major.sequraise.Assignment;

public class DataModel {
    String currentTime, captureCount, frequency, connectivity, batteryCharging, batteryLevel, location;


    public DataModel() {
    }

    public DataModel(String currentTime, String captureCount, String frequency, String connectivity, String batteryCharging, String batteryLevel, String location) {
        this.currentTime = currentTime;
        this.captureCount = captureCount;
        this.frequency = frequency;
        this.connectivity = connectivity;
        this.batteryCharging = batteryCharging;
        this.batteryLevel = batteryLevel;
        this.location = location;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getCaptureCount() {
        return captureCount;
    }

    public void setCaptureCount(String captureCount) {
        this.captureCount = captureCount;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getConnectivity() {
        return connectivity;
    }

    public void setConnectivity(String connectivity) {
        this.connectivity = connectivity;
    }

    public String getBatteryCharging() {
        return batteryCharging;
    }

    public void setBatteryCharging(String batteryCharging) {
        this.batteryCharging = batteryCharging;
    }

    public String getBatteryCharge() {
        return batteryLevel;
    }

    public void setBatteryCharge(String batteryCharge) {
        this.batteryLevel = batteryCharge;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
